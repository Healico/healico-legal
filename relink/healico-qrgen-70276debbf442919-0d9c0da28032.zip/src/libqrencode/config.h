/* minimal config for HarmonyOS NAPI build (LGPL-2.1 libqrencode v4.1.1) */
#define MAJOR_VERSION 4
#define MINOR_VERSION 1
#define MICRO_VERSION 1
#define VERSION "4.1.1"
#define STATIC_IN_RELEASE
#define HAVE_LIBPTHREAD 0
#define HAVE_LIBPNG 0
