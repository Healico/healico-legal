/**
 * NAPI bindings for libqrencode — QR matrix generation without the
 * 512-byte ScanKit cap (Yealico EFQRCode parity: version auto, up to v40).
 *
 * Exposed: generateQrMatrix(text: string, ecLevel: string): number[][]
 *   → rows of 0/1 module values, null on overflow.
 */

#include "napi/native_api.h"
#include <stdlib.h>
#include <string.h>
#include "libqrencode/qrencode.h"

static QRecLevel parseLevel(const char *s) {
    if (strcmp(s, "L") == 0) { return QR_ECLEVEL_L; }
    if (strcmp(s, "Q") == 0) { return QR_ECLEVEL_Q; }
    if (strcmp(s, "H") == 0) { return QR_ECLEVEL_H; }
    return QR_ECLEVEL_M;
}

static napi_value GenerateQrMatrix(napi_env env, napi_callback_info info) {
    size_t argc = 2;
    napi_value args[2] = {NULL};
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);

    // text
    size_t textLen = 0;
    napi_get_value_string_utf8(env, args[0], NULL, 0, &textLen);
    char *text = (char *)malloc(textLen + 1);
    napi_get_value_string_utf8(env, args[0], text, textLen + 1, &textLen);

    // ec level
    char level[8] = "M";
    size_t levelLen = 0;
    napi_get_value_string_utf8(env, args[1], NULL, 0, &levelLen);
    if (levelLen < sizeof(level)) {
        napi_get_value_string_utf8(env, args[1], level, sizeof(level), &levelLen);
    }

    QRcode *q = QRcode_encodeString8bit(text, 0, parseLevel(level));
    free(text);
    if (q == NULL) {
        napi_value nullVal;
        napi_get_null(env, &nullVal);
        return nullVal;
    }

    // build number[][] (module values 0/1)
    napi_value rows;
    napi_create_array_with_length(env, q->width, &rows);
    for (int r = 0; r < q->width; r++) {
        napi_value row;
        napi_create_array_with_length(env, q->width, &row);
        for (int c = 0; c < q->width; c++) {
            napi_value v;
            napi_create_uint32(env, q->data[r * q->width + c] & 1, &v);
            napi_set_element(env, row, c, v);
        }
        napi_set_element(env, rows, r, row);
    }
    int width = q->width;
    QRcode_free(q);

    // wrap { width, modules }
    napi_value result;
    napi_create_object(env, &result);
    napi_value widthVal;
    napi_create_int32(env, width, &widthVal);
    napi_set_named_property(env, result, "width", widthVal);
    napi_set_named_property(env, result, "modules", rows);
    return result;
}

EXTERN_C_START
static napi_value Init(napi_env env, napi_value exports) {
    napi_property_descriptor desc[] = {
        {"generateQrMatrix", NULL, GenerateQrMatrix, NULL, NULL, NULL, napi_default, NULL},
    };
    napi_define_properties(env, exports, sizeof(desc) / sizeof(desc[0]), desc);
    return exports;
}
EXTERN_C_END

static napi_module demoModule = {
    .nm_version = 1,
    .nm_flags = 0,
    .nm_filename = NULL,
    .nm_register_func = Init,
    .nm_modname = "qrgen",
    .nm_priv = ((void *)0),
    .reserved = {0},
};

extern "C" __attribute__((constructor)) void RegisterQrgenModule(void) {
    napi_module_register(&demoModule);
}
