# Healico / Libqrencode 修改与重新链接材料

本目录是履约包模板。公开交付包包含实际 `src/`、`objects/` 和 `manifest.json`；请从 [公开履约材料目录](https://github.com/Healico/healico-legal/tree/main/relink) 获取与接收版本匹配的包。

Healico 的 `libqrgen.so` 使用 Libqrencode 4.1.1（LGPL-2.1-or-later）。完整许可证见 `src/libqrencode/COPYING`。包内是实际编译使用的全部 C/H 源码、配置头、原 CMake 配置、NAPI 调用方源码，以及该版本调用方目标文件（仅去除调试信息）。库源码可按 LGPL 修改和分发。调用方源码/目标文件及本工具允许接收者为自己的使用进行修改、编译、重新链接、组合进自己接收的 Healico 副本，并为调试这些修改进行反向工程。此项授权不限制第三方许可证本身授予的权利，也不使 Healico 其余代码成为公开源码。

## 重新链接

需要 Python 3.9+ 和 DevEco 的 OpenHarmony Native SDK。当前包经 OHOS LLVM 15.0.4、arm64-v8a 验证；具体编译器标识和原库哈希见 `manifest.json`。操作系统、NAPI、系统库和工具链可从华为官方 DevEco/SDK 获取。已有 HAP 中的 `libc++_shared.so` 应继续保留，其通知包含在本包中。

1. 解压到新目录，核对 `manifest.json` 的逐文件 SHA-256（验证方法见后文）。
2. 修改 `src/libqrencode/` 中所需源码，保留与 `qrgen_napi.cpp` 兼容的 API。
3. 运行以下命令；将 SDK 路径替换为本机实际位置：

```sh
python3 relink.py --sdk /path/to/openharmony/native --output /tmp/healico-relinked
```

生成的 `libqrgen.so` 包含修改后的库和提供的调用方目标文件。脚本不依赖私有仓库或开发者签名密钥。`src/CMakeLists.txt` 是原构建配置，`relink.py` 是使用提供目标文件的等价独立链接流程。更换接口定义需要重新编译调用方时，可使用包内 `src/qrgen_napi.cpp` 与原 CMake 配置。

## 组合进自己接收的应用

可用 `--hap /path/to/received.hap` 传入已合法接收且哈希匹配的 HAP。工具只替换 `libs/arm64-v8a/libqrgen.so`，保留其他应用字节，输出 `entry-modified-unsigned.hap`。旧签名在重打包时失效；需要使用自己的 HarmonyOS 调试证书及适用的设备 profile，通过官方签名工具重新签名，再在自己的测试设备安装。原开发者证书和密钥不在本包内。签名身份变化通常不能覆盖已有安装，先自行备份数据并使用独立测试设备，不要通过卸载生产副本来测试。

我们已验证：未修改源码重新链接后的 `.text` 与对应发行库相同；修改库后可链接、导出新增测试符号并保留 NAPI 入口；重打包保留全部其他 HAP 条目。此处不宣称已在用户自有证书下完成整包签名/安装。正式 release 或市场加密产物需重新验证可获取的对应包和修改流程，不能沿用 debug 验收结论。

## 校验未修改的材料

在解压目录执行：

```sh
python3 - <<'PY'
import hashlib, json
from pathlib import Path
m = json.loads(Path('manifest.json').read_text())
for name, expected in m['files'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
print('材料校验通过')
PY
```

## 三年书面要约

对每个分发版本，自其分发日起至少三年内，可向 **healico@foxmail.com** 索取 LGPL 2.1 第 6(a) 条所指的对应机器可读源代码/目标代码及重新链接材料；费用不超过复制和分发成本。请附应用版本、构建号或原 `libqrgen.so` SHA-256，便于定位。公开链接不可用也不影响该要约。历史包应保留，不能用新包覆盖旧版本材料。
