#!/usr/bin/env python3
"""Rebuild the LGPL library and relink it with the supplied Healico object."""
import argparse
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCES = ['qrencode', 'qrinput', 'bitstream', 'qrspec', 'rsecc', 'split', 'mask', 'mqrspec', 'mmask']


def run(args):
    subprocess.run([str(x) for x in args], check=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sdk', required=True, type=Path, help='OpenHarmony native SDK directory (contains llvm and sysroot)')
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--hap', type=Path, help='Optional legally received matching HAP to rebuild without a signature')
    args = p.parse_args()
    sdk, out = args.sdk.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    base = ['--target=aarch64-linux-ohos', f'--gcc-toolchain={sdk / "llvm"}', f'--sysroot={sdk / "sysroot"}']
    flags = ['-fdata-sections', '-ffunction-sections', '-funwind-tables', '-fstack-protector-strong',
             '-no-canonical-prefixes', '-fno-addrsig', '-Wa,--noexecstack', '-Wformat',
             '-Werror=format-security', '-D__MUSL__', '-O0', '-std=gnu99', '-fPIC', '-DHAVE_CONFIG_H']
    objects = []
    for name in SOURCES:
        obj = out / (name + '.o')
        run([sdk / 'llvm/bin/clang', *base, *flags, '-I', ROOT / 'src/libqrencode',
             '-c', ROOT / f'src/libqrencode/{name}.c', '-o', obj])
        objects.append(obj)
    archive = out / 'libqrencode.a'
    # Remove only our own intermediate archive to avoid stale members.
    archive.unlink(missing_ok=True)
    run([sdk / 'llvm/bin/llvm-ar', 'qc', archive, *objects])
    run([sdk / 'llvm/bin/llvm-ranlib', archive])
    so = out / 'libqrgen.so'
    run([sdk / 'llvm/bin/clang++', *base, '--rtlib=compiler-rt', '-fuse-ld=lld',
         '-Wl,--build-id=sha1', '-Wl,--warn-shared-textrel', '-Wl,--fatal-warnings', '-lunwind',
         '-Wl,--no-undefined', '-Qunused-arguments', '-Wl,-z,noexecstack', '-shared',
         '-Wl,-soname,libqrgen.so', ROOT / 'objects/qrgen_napi.cpp.o', archive, '-lace_napi.z', '-lm', '-o', so])
    run([sdk / 'llvm/bin/llvm-strip', '--strip-unneeded', so])
    if args.hap:
        import hashlib
        manifest = json.loads((ROOT / 'manifest.json').read_text())
        member = 'libs/arm64-v8a/libqrgen.so'
        with zipfile.ZipFile(args.hap) as src:
            if hashlib.sha256(src.read(member)).hexdigest() != manifest['originalLibrarySha256']:
                raise SystemExit('HAP library does not match this materials package; request the matching version.')
            # Rewriting zip entries drops the HarmonyOS signing block. Re-sign with your own certificate.
            with zipfile.ZipFile(out / 'entry-modified-unsigned.hap', 'w') as dst:
                for item in src.infolist():
                    if item.filename.startswith('META-INF/'):
                        continue
                    dst.writestr(item, so.read_bytes() if item.filename == member else src.read(item.filename))
    print('Relinked:', so)


if __name__ == '__main__':
    main()
